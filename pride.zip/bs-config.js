module.exports = {
  server: true,
  files: ["./*.{html,css,js}"],
  // proxy: {
  //   target: "http://localhost:3000",
  //   ws: true,
  // },
  ui: false,
};
